# Discord Minecraft Registration Bot

## Overview

This is a Discord bot built with Python that allows users to register their Minecraft usernames within a Discord server. The bot stores user registration data in a designated channel and automatically assigns roles to registered users. It features both slash commands and traditional text commands for user interaction, with built-in validation and duplicate prevention mechanisms.

## System Architecture

The bot follows a simple, single-file architecture with modular configuration:

- **Core Bot Logic**: Implemented in `main.py` using discord.py library
- **Configuration Management**: Centralized in `config.py` with environment variable support
- **Utility Functions**: Separated into `utils.py` for reusability
- **Dependency Management**: Handled through `pyproject.toml` and `uv.lock`

## Key Components

### Bot Framework
- **discord.py**: Primary library for Discord API interaction
- **Commands Extension**: Supports both slash commands (`/`) and text commands (`!`)
- **Intents**: Configured for message content, guild access, and member management

### Configuration System
- **Environment Variables**: Primary configuration method for security
- **Fallback Values**: Default placeholder values for development
- **Validation**: Built-in configuration validation with error reporting

### Data Storage
- **Channel-Based Storage**: Uses Discord channels as a simple database
- **Embed Format**: Stores user data in Discord embeds for structured information
- **No External Database**: Relies entirely on Discord's infrastructure

### User Management
- **Registration System**: Handles Minecraft username registration
- **Unlink System**: Allows users to remove their registrations
- **Role Assignment**: Automatically assigns configured roles to registered users
- **Duplicate Prevention**: Prevents multiple registrations per user and duplicate Minecraft usernames

### Input Validation
- **Minecraft Username Rules**: Validates against Mojang's official standards
  - 3-16 characters length
  - Alphanumeric characters and underscores only
  - No leading/trailing underscores
  - No consecutive underscores

## Data Flow

1. **User Registration**:
   - User submits registration command with Minecraft username
   - Bot validates username format
   - Bot checks for existing registrations (user and username duplicates)
   - Bot stores data in designated channel as structured embed
   - Bot assigns configured role to user

2. **Admin Operations**:
   - Administrators can list all registrations
   - Data is retrieved from storage channel embeds
   - Formatted output displays all registered users

3. **Error Handling**:
   - Global error handler manages command errors
   - Permission checks for administrative functions
   - Graceful failure with user-friendly error messages

## External Dependencies

### Required Services
- **Discord Bot Token**: Authentication with Discord API
- **Discord Server**: Target server with appropriate permissions

### Bot Permissions
- Send Messages
- Use Slash Commands
- Manage Roles
- Read Message History
- Embed Links
- Add Reactions

### Python Dependencies
- `discord.py>=2.5.2`: Primary Discord API wrapper
- Python 3.11+: Runtime environment

## Deployment Strategy

### Environment Setup
- **Replit Integration**: Configured for Replit deployment with `.replit` file
- **Automated Installation**: Dependencies installed via pip during deployment
- **Workflow Configuration**: Parallel workflow setup for bot execution

### Configuration Requirements
Three essential environment variables must be set:
- `DISCORD_BOT_TOKEN`: Bot authentication token
- `STORAGE_CHANNEL_ID`: Channel for data storage
- `REGISTRATION_ROLE_ID`: Role to assign to registered users

### Runtime Execution
- Automatic dependency installation
- Bot startup with command synchronization
- Continuous operation for Discord event handling

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 23, 2025. Initial setup