import discord
from discord.ext import commands
import asyncio
import re
import json
import os
from config import Config
from utils import validate_minecraft_username, format_user_data, parse_stored_data

# Bot setup with intents
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    """Event triggered when bot is ready"""
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is in {len(bot.guilds)} guilds:')
    
    if len(bot.guilds) == 0:
        print("⚠️  BOT NOT INVITED TO ANY SERVERS!")
        print(f"Add the bot to your server using this invite link:")
        print(f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=268446720&scope=bot%20applications.commands")
        print("\nRequired permissions:")
        print("- Send Messages")
        print("- Use Slash Commands") 
        print("- Manage Roles")
        print("- Read Message History")
        print("- Embed Links")
        print("- Add Reactions")
    else:
        for guild in bot.guilds:
            print(f'  - {guild.name} (ID: {guild.id})')
    
    try:
        synced = await bot.tree.sync()
        print(f'Synced {len(synced)} command(s):')
        for cmd in synced:
            print(f'  - /{cmd.name}: {cmd.description}')
    except Exception as e:
        print(f'Failed to sync commands: {e}')

@bot.event
async def on_command_error(ctx, error):
    """Global error handler for commands"""
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ You don't have permission to use this command.")
    else:
        await ctx.send(f"❌ An error occurred: {str(error)}")
        print(f"Error: {error}")

async def get_storage_channel():
    """Get the designated storage channel"""
    print(f"Looking for channel ID: {Config.STORAGE_CHANNEL_ID}")
    channel = bot.get_channel(Config.STORAGE_CHANNEL_ID)
    
    if not channel:
        print(f"Channel not found! Bot is in {len(bot.guilds)} guilds")
        for guild in bot.guilds:
            print(f"Guild: {guild.name} (ID: {guild.id})")
            for ch in guild.channels:
                if str(ch.id) == str(Config.STORAGE_CHANNEL_ID):
                    print(f"Found matching channel: {ch.name} (Type: {type(ch).__name__})")
        raise ValueError(f"Storage channel with ID {Config.STORAGE_CHANNEL_ID} not found. Please check the channel ID in config.")
    
    print(f"Found channel: {channel.name} (Type: {type(channel).__name__})")
    
    # Check if it's a text channel that supports messages
    if not isinstance(channel, discord.TextChannel):
        raise ValueError(f"Storage channel '{channel.name}' must be a text channel, not a {type(channel).__name__}.")
    
    return channel

async def get_registration_role(guild):
    """Get the role to assign to registered users"""
    print(f"Looking for role ID: {Config.REGISTRATION_ROLE_ID}")
    role = guild.get_role(Config.REGISTRATION_ROLE_ID)
    
    if not role:
        print(f"Role not found! Available roles in guild:")
        for r in guild.roles:
            print(f"  - {r.name} (ID: {r.id})")
        raise ValueError(f"Registration role with ID {Config.REGISTRATION_ROLE_ID} not found. Please check the role ID in config.")
    
    print(f"Found role: {role.name}")
    
    # Check if bot can manage this role
    bot_member = guild.me
    if role.position >= bot_member.top_role.position:
        raise ValueError(f"Bot's highest role is below the target role '{role.name}'. Move the bot's role higher in the server settings.")
    
    if not bot_member.guild_permissions.manage_roles:
        raise ValueError("Bot doesn't have 'Manage Roles' permission")
    
    return role

async def check_existing_registration(user_id, minecraft_username):
    """Check if user is already registered or username is taken"""
    storage_channel = await get_storage_channel()
    
    async for message in storage_channel.history(limit=None):
        if message.author == bot.user and message.embeds:
            embed = message.embeds[0]
            stored_data = parse_stored_data(embed)
            
            if stored_data:
                # Check if Discord user is already registered
                if stored_data['discord_id'] == str(user_id):
                    return 'user_exists', stored_data['minecraft_username']
                
                # Check if Minecraft username is already taken
                if stored_data['minecraft_username'].lower() == minecraft_username.lower():
                    return 'username_taken', stored_data['discord_name']
    
    return None, None

async def store_user_data(user, minecraft_username):
    """Store user data in the designated channel"""
    storage_channel = await get_storage_channel()
    
    # Check if bot has permission to send messages in the channel
    permissions = storage_channel.permissions_for(storage_channel.guild.me)
    if not permissions.send_messages:
        raise discord.Forbidden(None, "Bot doesn't have permission to send messages in the storage channel")
    if not permissions.embed_links:
        raise discord.Forbidden(None, "Bot doesn't have permission to embed links in the storage channel")
    
    embed = discord.Embed(
        title="📋 User Registration",
        color=0x00ff00,
        timestamp=discord.utils.utcnow()
    )
    
    embed.add_field(name="Discord Name", value=user.display_name, inline=True)
    embed.add_field(name="Discord ID", value=str(user.id), inline=True)
    embed.add_field(name="Minecraft Username", value=minecraft_username, inline=True)
    embed.add_field(name="Registration Date", value=discord.utils.format_dt(discord.utils.utcnow(), style='F'), inline=False)
    
    embed.set_footer(text=f"Registered by {user.display_name}")
    
    if user.avatar:
        embed.set_thumbnail(url=user.avatar.url)
    
    await storage_channel.send(embed=embed)

# Slash command for registration
@bot.tree.command(name="register", description="Register your Minecraft username")
async def register_slash(interaction: discord.Interaction, minecraft_username: str):
    """Slash command to register Minecraft username"""
    await interaction.response.defer()
    
    try:
        # Validate Minecraft username
        if not validate_minecraft_username(minecraft_username):
            await interaction.followup.send("❌ Invalid Minecraft username! Usernames must be 3-16 characters long and contain only letters, numbers, and underscores.", ephemeral=True)
            return
        
        # Check for existing registration
        status, existing_data = await check_existing_registration(interaction.user.id, minecraft_username)
        
        if status == 'user_exists':
            await interaction.followup.send(f"❌ You are already registered with the Minecraft username: **{existing_data}**", ephemeral=True)
            return
        
        if status == 'username_taken':
            await interaction.followup.send(f"❌ The Minecraft username **{minecraft_username}** is already registered by **{existing_data}**", ephemeral=True)
            return
        
        # Store user data
        await store_user_data(interaction.user, minecraft_username)
        
        # Assign role
        try:
            role = await get_registration_role(interaction.guild)
            if hasattr(interaction.user, 'add_roles'):
                await interaction.user.add_roles(role)
            else:
                # For Member objects, we need to use the guild's member
                member = interaction.guild.get_member(interaction.user.id)
                if member:
                    await member.add_roles(role)
                else:
                    await interaction.followup.send("⚠️ Registration successful, but couldn't find you as a member to assign the role.", ephemeral=True)
                    return
        except discord.Forbidden:
            await interaction.followup.send("⚠️ Registration successful, but I couldn't assign the role. Please check my permissions.", ephemeral=True)
            return
        except Exception as role_error:
            await interaction.followup.send(f"⚠️ Registration successful, but role assignment failed: {str(role_error)}", ephemeral=True)
            return
        
        # Success message
        embed = discord.Embed(
            title="✅ Registration Successful!",
            description=f"Welcome to the server, **{interaction.user.display_name}**!",
            color=0x00ff00
        )
        embed.add_field(name="Minecraft Username", value=minecraft_username, inline=True)
        embed.add_field(name="Role Assigned", value=role.name, inline=True)
        
        await interaction.followup.send(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.followup.send(f"❌ An error occurred during registration: {str(e)}", ephemeral=True)
        print(f"Registration error: {e}")

# Text command for registration (backup)
@bot.command(name='register')
async def register_text(ctx, minecraft_username: str = None):
    """Text command to register Minecraft username"""
    if not minecraft_username:
        await ctx.send("❌ Please provide your Minecraft username! Usage: `!register <minecraft_username>`", delete_after=10)
        return
    
    try:
        # Validate Minecraft username
        if not validate_minecraft_username(minecraft_username):
            await ctx.send("❌ Invalid Minecraft username! Usernames must be 3-16 characters long and contain only letters, numbers, and underscores.", delete_after=10)
            return
        
        # Check for existing registration
        status, existing_data = await check_existing_registration(ctx.author.id, minecraft_username)
        
        if status == 'user_exists':
            await ctx.send(f"❌ You are already registered with the Minecraft username: **{existing_data}**", delete_after=10)
            return
        
        if status == 'username_taken':
            await ctx.send(f"❌ The Minecraft username **{minecraft_username}** is already registered by **{existing_data}**", delete_after=10)
            return
        
        # Store user data
        await store_user_data(ctx.author, minecraft_username)
        
        # Assign role
        role = await get_registration_role(ctx.guild)
        await ctx.author.add_roles(role)
        
        # Success message
        embed = discord.Embed(
            title="✅ Registration Successful!",
            description=f"Welcome to the server, **{ctx.author.display_name}**!",
            color=0x00ff00
        )
        embed.add_field(name="Minecraft Username", value=minecraft_username, inline=True)
        embed.add_field(name="Role Assigned", value=role.name, inline=True)
        
        await ctx.send(embed=embed, delete_after=15)
        
    except Exception as e:
        await ctx.send(f"❌ An error occurred during registration: {str(e)}")
        print(f"Registration error: {e}")

# Slash command for unlinking
@bot.tree.command(name="unlink", description="Remove your Minecraft username registration")
async def unlink_slash(interaction: discord.Interaction):
    """Slash command to unlink Minecraft username"""
    await interaction.response.defer(ephemeral=True)
    
    try:
        storage_channel = await get_storage_channel()
        user_found = False
        
        # Search for user's registration
        async for message in storage_channel.history(limit=None):
            if message.author == bot.user and message.embeds:
                embed = message.embeds[0]
                stored_data = parse_stored_data(embed)
                
                if stored_data and stored_data['discord_id'] == str(interaction.user.id):
                    # Found user's registration - keep original message and add unlink message
                    user_found = True
                    
                    # Create unlink log message
                    unlink_embed = discord.Embed(
                        title="🔗 User Unlinked",
                        color=0xff9900,
                        timestamp=discord.utils.utcnow()
                    )
                    
                    unlink_embed.add_field(name="Discord Name", value=interaction.user.display_name, inline=True)
                    unlink_embed.add_field(name="Discord ID", value=str(interaction.user.id), inline=True)
                    unlink_embed.add_field(name="Previous Minecraft Username", value=stored_data['minecraft_username'], inline=True)
                    unlink_embed.add_field(name="Unlink Date", value=discord.utils.format_dt(discord.utils.utcnow(), style='F'), inline=False)
                    
                    unlink_embed.set_footer(text=f"Unlinked by {interaction.user.display_name}")
                    
                    if interaction.user.avatar:
                        unlink_embed.set_thumbnail(url=interaction.user.avatar.url)
                    
                    await storage_channel.send(embed=unlink_embed)
                    
                    # Try to remove role
                    try:
                        role = await get_registration_role(interaction.guild)
                        member = interaction.guild.get_member(interaction.user.id)
                        if member and role in member.roles:
                            await member.remove_roles(role)
                    except Exception as role_error:
                        print(f"Role removal error: {role_error}")
                    
                    # Success message
                    embed = discord.Embed(
                        title="✅ Successfully Unlinked!",
                        description=f"Your Minecraft registration has been removed, **{interaction.user.display_name}**.",
                        color=0x00ff00
                    )
                    embed.add_field(name="Previous Minecraft Username", value=stored_data['minecraft_username'], inline=True)
                    
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    return
        
        if not user_found:
            await interaction.followup.send("❌ You don't have any Minecraft username registered.", ephemeral=True)
            
    except Exception as e:
        await interaction.followup.send(f"❌ An error occurred during unlinking: {str(e)}", ephemeral=True)
        print(f"Unlink error: {e}")

# Text command for unlinking
@bot.command(name='unlink')
async def unlink_text(ctx):
    """Text command to unlink Minecraft username"""
    try:
        storage_channel = await get_storage_channel()
        user_found = False
        
        # Search for user's registration
        async for message in storage_channel.history(limit=None):
            if message.author == bot.user and message.embeds:
                embed = message.embeds[0]
                stored_data = parse_stored_data(embed)
                
                if stored_data and stored_data['discord_id'] == str(ctx.author.id):
                    # Found user's registration - keep original message and add unlink message
                    user_found = True
                    
                    # Create unlink log message
                    unlink_embed = discord.Embed(
                        title="🔗 User Unlinked",
                        color=0xff9900,
                        timestamp=discord.utils.utcnow()
                    )
                    
                    unlink_embed.add_field(name="Discord Name", value=ctx.author.display_name, inline=True)
                    unlink_embed.add_field(name="Discord ID", value=str(ctx.author.id), inline=True)
                    unlink_embed.add_field(name="Previous Minecraft Username", value=stored_data['minecraft_username'], inline=True)
                    unlink_embed.add_field(name="Unlink Date", value=discord.utils.format_dt(discord.utils.utcnow(), style='F'), inline=False)
                    
                    unlink_embed.set_footer(text=f"Unlinked by {ctx.author.display_name}")
                    
                    if ctx.author.avatar:
                        unlink_embed.set_thumbnail(url=ctx.author.avatar.url)
                    
                    await storage_channel.send(embed=unlink_embed)
                    
                    # Try to remove role
                    try:
                        role = await get_registration_role(ctx.guild)
                        if role in ctx.author.roles:
                            await ctx.author.remove_roles(role)
                    except Exception as role_error:
                        print(f"Role removal error: {role_error}")
                    
                    # Success message
                    embed = discord.Embed(
                        title="✅ Successfully Unlinked!",
                        description=f"Your Minecraft registration has been removed, **{ctx.author.display_name}**.",
                        color=0x00ff00
                    )
                    embed.add_field(name="Previous Minecraft Username", value=stored_data['minecraft_username'], inline=True)
                    
                    await ctx.send(embed=embed, delete_after=15)
                    return
        
        if not user_found:
            await ctx.send("❌ You don't have any Minecraft username registered.", delete_after=10)
            
    except Exception as e:
        await ctx.send(f"❌ An error occurred during unlinking: {str(e)}", delete_after=10)
        print(f"Unlink error: {e}")

# Admin command to view registrations
@bot.tree.command(name="list_registrations", description="List all registered users (Admin only)")
@discord.app_commands.default_permissions(administrator=True)
async def list_registrations(interaction: discord.Interaction):
    """Admin command to list all registrations"""
    await interaction.response.defer()
    
    try:
        storage_channel = await get_storage_channel()
        registrations = []
        
        async for message in storage_channel.history(limit=None):
            if message.author == bot.user and message.embeds:
                embed = message.embeds[0]
                stored_data = parse_stored_data(embed)
                if stored_data:
                    registrations.append(stored_data)
        
        if not registrations:
            await interaction.followup.send("📋 No registrations found.")
            return
        
        # Create paginated response
        embed = discord.Embed(
            title="📋 Registered Users",
            description=f"Total registrations: {len(registrations)}",
            color=0x0099ff
        )
        
        # Show first 10 registrations
        for i, reg in enumerate(registrations[:10]):
            embed.add_field(
                name=f"{i+1}. {reg['discord_name']}",
                value=f"Minecraft: **{reg['minecraft_username']}**\nID: {reg['discord_id']}",
                inline=True
            )
        
        if len(registrations) > 10:
            embed.set_footer(text=f"Showing first 10 of {len(registrations)} registrations")
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ An error occurred: {str(e)}")
        print(f"List registrations error: {e}")

# Debug slash command for permissions testing
@bot.tree.command(name="check_permissions", description="Check bot permissions (Admin only)")
@discord.app_commands.default_permissions(administrator=True)
async def check_permissions_slash(interaction: discord.Interaction):
    """Check bot permissions for storage channel and role management"""
    await interaction.response.defer(ephemeral=True)
    
    try:
        issues = []
        
        # Check storage channel
        try:
            channel = bot.get_channel(Config.STORAGE_CHANNEL_ID)
            if channel:
                perms = channel.permissions_for(interaction.guild.me)
                channel_status = f"✅ Storage channel '{channel.name}' found"
                if not perms.send_messages:
                    issues.append("❌ Missing 'Send Messages' in storage channel")
                if not perms.embed_links:
                    issues.append("❌ Missing 'Embed Links' in storage channel") 
                if not perms.read_message_history:
                    issues.append("❌ Missing 'Read Message History' in storage channel")
            else:
                issues.append(f"❌ Storage channel ID {Config.STORAGE_CHANNEL_ID} not found")
                channel_status = "❌ Storage channel not found"
        except Exception as e:
            issues.append(f"❌ Storage channel error: {str(e)}")
            channel_status = "❌ Storage channel error"
        
        # Check registration role
        try:
            role = interaction.guild.get_role(Config.REGISTRATION_ROLE_ID)
            if role:
                bot_member = interaction.guild.me
                role_status = f"✅ Registration role '{role.name}' found"
                
                if not bot_member.guild_permissions.manage_roles:
                    issues.append("❌ Missing 'Manage Roles' server permission")
                
                if role.position >= bot_member.top_role.position:
                    issues.append(f"❌ Bot role is below target role '{role.name}' - move bot role higher")
            else:
                issues.append(f"❌ Registration role ID {Config.REGISTRATION_ROLE_ID} not found")
                role_status = "❌ Registration role not found"
        except Exception as e:
            issues.append(f"❌ Registration role error: {str(e)}")
            role_status = "❌ Registration role error"
        
        # Build response
        response = f"**Permission Check Results:**\n\n{channel_status}\n{role_status}\n\n"
        
        if issues:
            response += "**Issues Found:**\n" + "\n".join(issues)
        else:
            response += "✅ All permissions look good!"
            
        await interaction.followup.send(response, ephemeral=True)
            
    except Exception as e:
        await interaction.followup.send(f"❌ Permission check error: {str(e)}", ephemeral=True)

# Text version of debug command as backup
@bot.command(name='debug')
async def debug_channel_text(ctx):
    """Text debug command to check channel configuration"""
    try:
        channel = bot.get_channel(Config.STORAGE_CHANNEL_ID)
        
        if not channel:
            guild_info = ""
            for guild in bot.guilds:
                guild_info += f"\n- {guild.name} (ID: {guild.id})"
                for ch in guild.channels:
                    if str(ch.id) == str(Config.STORAGE_CHANNEL_ID):
                        guild_info += f"\n  Found matching channel: {ch.name} (Type: {type(ch).__name__})"
            
            await ctx.send(f"❌ Channel ID {Config.STORAGE_CHANNEL_ID} not found!\nBot is in {len(bot.guilds)} guilds:{guild_info}")
        else:
            await ctx.send(f"✅ Found channel: {channel.name} (Type: {type(channel).__name__})")
            
    except Exception as e:
        await ctx.send(f"❌ Debug error: {str(e)}")

# Help command
@bot.command(name='help_register')
async def help_register(ctx):
    """Help command for registration"""
    embed = discord.Embed(
        title="🎮 Minecraft Registration Help",
        description="Register your Minecraft username to get access to server features!",
        color=0x0099ff
    )
    
    embed.add_field(
        name="📝 Registration Commands",
        value="`/register <minecraft_username>` - Register using slash command\n`!register <minecraft_username>` - Register using text command\n`/unlink` - Remove your registration\n`!unlink` - Remove your registration",
        inline=False
    )
    
    embed.add_field(
        name="📋 Username Requirements",
        value="• 3-16 characters long\n• Only letters, numbers, and underscores\n• Must be a valid Minecraft username",
        inline=False
    )
    
    embed.add_field(
        name="ℹ️ Important Notes",
        value="• You can only register once\n• Each Minecraft username can only be used once\n• You'll automatically receive a role upon registration",
        inline=False
    )
    
    await ctx.send(embed=embed)

if __name__ == "__main__":
    # Run the bot
    bot.run(Config.BOT_TOKEN)
