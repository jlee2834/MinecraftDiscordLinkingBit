import re
import discord

def validate_minecraft_username(username):
    """
    Validate Minecraft username format
    
    Rules:
    - 3-16 characters long
    - Only letters, numbers, and underscores
    - Cannot start or end with underscore
    """
    if not username:
        return False
    
    # Basic length check
    if len(username) < 3 or len(username) > 16:
        return False
    
    # Character validation (letters, numbers, underscores only)
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return False
    
    # Cannot start or end with underscore
    if username.startswith('_') or username.endswith('_'):
        return False
    
    # Cannot have consecutive underscores
    if '__' in username:
        return False
    
    return True

def format_user_data(discord_name, discord_id, minecraft_username):
    """Format user data for storage"""
    return {
        'discord_name': discord_name,
        'discord_id': str(discord_id),
        'minecraft_username': minecraft_username
    }

def parse_stored_data(embed):
    """Parse user data from stored embed"""
    try:
        if not embed or not embed.fields:
            return None
        
        data = {}
        for field in embed.fields:
            if field.name == "Discord Name":
                data['discord_name'] = field.value
            elif field.name == "Discord ID":
                data['discord_id'] = field.value
            elif field.name == "Minecraft Username":
                data['minecraft_username'] = field.value
        
        # Ensure all required fields are present
        if all(key in data for key in ['discord_name', 'discord_id', 'minecraft_username']):
            return data
        
        return None
    
    except Exception as e:
        print(f"Error parsing stored data: {e}")
        return None

def create_registration_embed(user, minecraft_username):
    """Create a formatted embed for successful registration"""
    embed = discord.Embed(
        title="✅ Registration Successful!",
        description=f"Welcome to the server, **{user.display_name}**!",
        color=0x00ff00,
        timestamp=discord.utils.utcnow()
    )
    
    embed.add_field(name="Discord User", value=user.display_name, inline=True)
    embed.add_field(name="Minecraft Username", value=minecraft_username, inline=True)
    embed.add_field(name="User ID", value=str(user.id), inline=True)
    
    if user.avatar:
        embed.set_thumbnail(url=user.avatar.url)
    
    embed.set_footer(text="Registration completed successfully")
    
    return embed

def create_error_embed(title, description, color=0xff0000):
    """Create a formatted error embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color
    )
    
    return embed

def sanitize_username(username):
    """Sanitize username input"""
    if not username:
        return ""
    
    # Remove extra spaces and convert to lowercase for comparison
    return username.strip()

def is_valid_discord_id(user_id):
    """Check if a Discord ID is valid format"""
    try:
        return isinstance(user_id, int) or (isinstance(user_id, str) and user_id.isdigit() and len(user_id) >= 17)
    except:
        return False

def format_registration_list(registrations, page=1, per_page=10):
    """Format a list of registrations for display"""
    if not registrations:
        return "No registrations found."
    
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    page_registrations = registrations[start_idx:end_idx]
    
    formatted_list = []
    for i, reg in enumerate(page_registrations, start=start_idx + 1):
        formatted_list.append(f"{i}. **{reg['discord_name']}** → {reg['minecraft_username']}")
    
    return "\n".join(formatted_list)

def get_username_suggestions(partial_username):
    """Get suggestions for partial username input (basic implementation)"""
    suggestions = []
    
    if len(partial_username) < 3:
        suggestions.append("Username must be at least 3 characters long")
    
    if len(partial_username) > 16:
        suggestions.append("Username must be no more than 16 characters long")
    
    if not re.match(r'^[a-zA-Z0-9_]*$', partial_username):
        suggestions.append("Username can only contain letters, numbers, and underscores")
    
    if partial_username.startswith('_') or partial_username.endswith('_'):
        suggestions.append("Username cannot start or end with underscore")
    
    if '__' in partial_username:
        suggestions.append("Username cannot contain consecutive underscores")
    
    return suggestions
