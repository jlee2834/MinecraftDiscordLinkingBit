# Discord Minecraft Registration Bot -- JLEE2834

A Discord bot that allows users to register their Minecraft usernames, stores their data in a designated channel, and assigns them a role automatically.

## Features

- **User Registration**: Users can register their Minecraft usernames using slash commands or text commands
- **Data Storage**: User data (Discord name, Discord ID, Minecraft username) is stored in a designated channel
- **Role Assignment**: Automatically assigns a specified role to registered users
- **Duplicate Prevention**: Prevents users from registering multiple times and prevents duplicate Minecraft usernames
- **Admin Commands**: Administrators can view all registrations
- **Input Validation**: Validates Minecraft username format according to Mojang standards

## Commands

### User Commands
- `/register <minecraft_username>` - Register your Minecraft username (slash command)
- `!register <minecraft_username>` - Register your Minecraft username (text command)
- `!help_register` - Show help information about registration

### Admin Commands
- `/list_registrations` - List all registered users (requires Administrator permission)

## Setup Instructions

### 1. Bot Creation
1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application and navigate to the "Bot" section
3. Create a bot and copy the bot token
4. Enable the following intents:
   - Message Content Intent
   - Server Members Intent

### 2. Bot Permissions
Ensure your bot has the following permissions:
- Send Messages
- Use Slash Commands
- Manage Roles
- Read Message History
- Embed Links
- Add Reactions

### 3. Configuration

#### Environment Variables (Recommended)
Set the following environment variables:
```bash
export DISCORD_BOT_TOKEN="your_bot_token_here"
export STORAGE_CHANNEL_ID="channel_id_for_storing_data"
export REGISTRATION_ROLE_ID="role_id_to_assign"
