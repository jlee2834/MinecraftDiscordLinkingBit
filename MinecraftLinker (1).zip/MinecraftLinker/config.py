import os

class Config:
    """Configuration class for the Discord bot"""
    
    # Bot token from environment variable
    BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "your_bot_token_here")
    
    # Channel ID where user data will be stored
    # Replace with your actual channel ID
    STORAGE_CHANNEL_ID = int(os.getenv("STORAGE_CHANNEL_ID", "1234567890123456789"))
    
    # Role ID to assign to registered users
    # Replace with your actual role ID
    REGISTRATION_ROLE_ID = int(os.getenv("REGISTRATION_ROLE_ID", "1234567890123456789"))
    
    # Bot settings
    COMMAND_PREFIX = "!"
    
    @classmethod
    def validate_config(cls):
        """Validate that all required configuration is present"""
        errors = []
        
        if cls.BOT_TOKEN == "your_bot_token_here":
            errors.append("BOT_TOKEN not set. Please set the DISCORD_BOT_TOKEN environment variable.")
        
        if cls.STORAGE_CHANNEL_ID == 1234567890123456789:
            errors.append("STORAGE_CHANNEL_ID not set. Please set the STORAGE_CHANNEL_ID environment variable.")
        
        if cls.REGISTRATION_ROLE_ID == 1234567890123456789:
            errors.append("REGISTRATION_ROLE_ID not set. Please set the REGISTRATION_ROLE_ID environment variable.")
        
        if errors:
            print("Configuration Errors:")
            for error in errors:
                print(f"- {error}")
            print("\nPlease check your environment variables or update config.py directly.")
            return False
        
        return True

# Validate configuration on import
if __name__ == "__main__":
    Config.validate_config()
